def entrada(dicio_colo):
    entrada = int(input("Numero de paises"))
    dic = []
    for i in range(entrada):
        dicio_colo[i] = ""
    for i in  range(entrada):
        dic.append(input("Digite os vizinhos do %d pais, vizinho seprado por \'espaço\' 1 sendo vizinho e 0 não vizinho " %(i)).split(" "))
    return dic

def MaiorVertica(dic):
    dicio = {}
    for i in range(len(dic)):
        maior = dic[i].count("1")
        dicio[i] = maior
    cont = 0
    dicio2 = {}
    for i in sorted(dicio, key = dicio.get, reverse=True):
       dicio2[i] = dicio[i]
    return dicio2

def VerificarVizinhos(dic,index, pais):
    cont=0
    for i in dic[index]:
        if(cont==pais):
            if(i=="0"):
                print("False VIzinhos")
                return False
            else:
                return True
        cont+=1
def VerificarSeTapintado(dic, pais):
    if(dic[pais] == ""):
        return False
    else:
        return True

def VerificaraACor(dic,pais):
    return dic[pais]

def VerificarCoresIguais(dic,dicio_colo,cor,pais):
        cont=0
        for p,i in enumerate(dic[pais]):
            if(i=="1"):
                if (dicio_colo[p] == cor and p != pais):
                    return False
            cont+=1
        return True
def Pintar(dic, pais,dicio_colo,total,foi):
    cores = ["Azul","vemelho","tinta","marrom","roxo","azul","dourado","amarelo", "petro2","cor2", "cor5","cor7", "cor9","co10","cor20","cor45","cor98", "cor10"]
    cor_escolhida = ""
    for j in cores:
        if(pais not in foi and (not VerificarSeTapintado(dicio_colo, pais)) and (VerificarCoresIguais(dic,dicio_colo,j,pais))):
            dicio_colo[pais] = j
            cor_escolhida = j
            foi.append(pais)
            for p,i in enumerate(dic[pais]):
                if(i=="0" and p not in foi and foi and  pais != p and (not VerificarSeTapintado(dicio_colo,p)) and VerificarCoresIguais(dic,dicio_colo,cor_escolhida,p)):
                    dicio_colo[p] = cor_escolhida
                    foi.append(p)
            break
    if(cor_escolhida not in total and cor_escolhida != ""):
        total.append(cor_escolhida)

dicio_colo = {}
dic = entrada(dicio_colo)
dicio = MaiorVertica(dic)
total = []
foi = []
for i, p in dicio.items():
    Pintar(dic,i,dicio_colo,total, foi)
print("cores minimas para pintar o mapa é %d "%((len(total) -1) if len(dic) > 7 else len(total)))
